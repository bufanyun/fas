﻿<?php
include('head.php');
include('nav.php');
?>
<script>
window.location.href='https://www.dingd.cn/app/';
</script>
<?php include("footer.php");?>